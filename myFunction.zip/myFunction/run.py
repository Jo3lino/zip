import azure.functions as func
import logging
from azure.storage.blob import BlobServiceClient

# Connection string to your Azure Storage account
CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=outputfile0109;AccountKey=1RT59lvE8V1D+HQ9JHmeO/f8GdNLAxv+/boJ/W1X9mt+Ij6c0zmXfWzZ2ppFeBphrt8s4JCwylGz+ASt5FdkEg==;EndpointSuffix=core.windows.net"

# Create a BlobServiceClient object
blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)

def main(req: func.HttpRequest, res: func.Out[func.HttpResponse]) -> None:
    logging.info('Python HTTP trigger function processed a request.')

    # Get 'name' parameter from the query string or request body
    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        # Define the containers and blob names
        source_container_name = "container1"  # Replace with your source container name
        source_blob_name = "testtest.txt..txt"  # Replace with your source blob name
        destination_container_name = "container2"  # Replace with your destination container name
        destination_blob_name = f"output-{name}.txt"  # Define the destination blob name dynamically

        try:
            # Create the destination container if it doesn't exist
            container_client = blob_service_client.get_container_client(destination_container_name)
            if not container_client.exists():
                container_client.create_container()
                logging.info(f"Container '{destination_container_name}' created successfully.")

            # Create a blob client for the source blob
            source_blob_client = blob_service_client.get_blob_client(container=source_container_name, blob=source_blob_name)

            # Download source blob data
            download_stream = source_blob_client.download_blob()
            blob_data = download_stream.readall()  # Keep it in bytes for uploading

            # Create a blob client for the destination blob
            destination_blob_client = container_client.get_blob_client(destination_blob_name)

            # Ensure blob_data is correctly formatted before uploading
            if isinstance(blob_data, bytes):
                # Upload the blob data to the new container
                destination_blob_client.upload_blob(blob_data, overwrite=True)
                logging.info(f"Data successfully uploaded to {destination_container_name}/{destination_blob_name}")

                # Set the response body and status code
                res.set(func.HttpResponse(f"Hello, {name}. Your file has been successfully saved as '{destination_blob_name}' in container '{destination_container_name}'.", status_code=200))
            else:
                logging.error("Blob data is not in the expected byte format.")
                res.set(func.HttpResponse("Blob data is not in the expected byte format.", status_code=500))
                
        except Exception as e:
            logging.error(f"Error accessing or uploading to blob storage: {e}")
            res.set(func.HttpResponse("Error accessing or uploading to blob storage.", status_code=500))
    else:
        res.set(func.HttpResponse("This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.", status_code=200))
